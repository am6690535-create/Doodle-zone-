import React, { useState, useEffect, useMemo, useRef } from 'react';
import { INITIAL_SHOP_INFO, INITIAL_PRODUCTS, ADMIN_CREDENTIALS, SHOP_LOCATION } from './constants';
import { Category, Product, ShopDetails, Order } from './types';

// --- Utilities ---

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371;
  const toRad = (value: number) => (value * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
};

interface CartItem {
  product: Product;
  quantity: number;
}

interface SaleRecord {
  id: string;
  timestamp: number;
  total: number;
  itemCount: number;
  items: CartItem[];
  customerName: string;
}

// --- Sub-components ---

const Header: React.FC<{
  onSearch: (q: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  shopName: string;
  isAdmin: boolean;
}> = ({ onSearch, cartCount, onOpenCart, shopName, isAdmin }) => (
  <header className="glass sticky top-0 z-50 px-6 py-4 flex flex-col gap-4 border-b border-white/40 android-shadow">
    <div className="flex justify-between items-center">
      <div className="flex flex-col">
        <h1 className="text-xl font-black gradient-text uppercase tracking-tighter">
          {shopName}
        </h1>
        <div className="flex items-center gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${isAdmin ? 'bg-amber-500' : 'bg-emerald-500'}`}></span>
          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
            {isAdmin ? 'Owner Mode Active' : 'Online Store'}
          </span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button 
          onClick={onOpenCart} 
          className="relative p-3 bg-violet-600 text-white rounded-2xl shadow-lg shadow-violet-200 active:scale-90 transition-transform"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-fuchsia-500 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">{cartCount}</span>
          )}
        </button>
      </div>
    </div>
    <div className="relative group">
      <input 
        type="text" 
        onChange={(e) => onSearch(e.target.value)}
        placeholder="Search for toys, stationery..." 
        className="w-full bg-slate-50 border border-slate-100 rounded-[1.25rem] py-3.5 pl-12 pr-6 text-sm font-bold outline-none focus:bg-white focus:ring-4 focus:ring-violet-50 transition-all shadow-inner"
      />
      <svg className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-violet-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
    </div>
  </header>
);

const ProductCard: React.FC<{ 
  product: Product; 
  onAddToCart: (p: Product) => void;
  isAdmin: boolean;
  onEdit?: (p: Product) => void;
}> = ({ product, onAddToCart, isAdmin, onEdit }) => (
  <div className="group relative bg-white rounded-[2.5rem] p-4 android-shadow border border-slate-100 flex flex-col gap-3 transition-all hover:-translate-y-1 active:scale-[0.98]">
    <div className="relative aspect-square bg-slate-50 rounded-[2rem] overflow-hidden border border-slate-100 flex items-center justify-center shadow-inner">
      {product.image ? (
        <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
      ) : (
        <div className="flex flex-col items-center gap-1 opacity-20">
          <svg className="w-10 h-10 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
        </div>
      )}
      {isAdmin && (
        <button 
          onClick={(e) => { e.stopPropagation(); onEdit?.(product); }}
          className="absolute top-3 right-3 p-2.5 bg-white/80 text-violet-600 rounded-xl backdrop-blur shadow-sm border border-white/50"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
        </button>
      )}
    </div>
    <div className="flex flex-col gap-1 px-1">
      <span className="text-[8px] font-black uppercase tracking-[0.2em] text-fuchsia-500">{product.category}</span>
      <h3 className="font-bold text-slate-800 text-xs leading-tight h-8 line-clamp-2">{product.name}</h3>
      <div className="flex justify-between items-center mt-1">
        <p className="text-base font-black text-slate-900 leading-none">
          <span className="text-[9px] font-bold text-slate-400 mr-0.5">Rs.</span>{product.price}
        </p>
        <button 
          onClick={() => onAddToCart(product)}
          className="bg-violet-600 text-white px-5 py-2 rounded-2xl shadow-lg active:scale-90 transition-all text-[10px] font-black tracking-widest uppercase"
        >
          BUY
        </button>
      </div>
    </div>
  </div>
);

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'Home' | 'Explore' | 'Me'>('Home');
  const [isSplashScreen, setIsSplashScreen] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Data State
  const [customerProfile, setCustomerProfile] = useState<{name: string, pin: string} | null>(() => {
    const saved = localStorage.getItem('doodle_customer_profile');
    return saved ? JSON.parse(saved) : null;
  });
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('doodle_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });
  const [salesHistory, setSalesHistory] = useState<SaleRecord[]>(() => {
    const saved = localStorage.getItem('doodle_sales_history');
    return saved ? JSON.parse(saved) : [];
  });
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isAdmin, setIsAdmin] = useState<boolean>(() => localStorage.getItem('doodle_is_admin') === 'true');
  const [shopInfo] = useState<ShopDetails>(INITIAL_SHOP_INFO);

  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<Category | 'All'>('All');
  
  // UI States
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showCartModal, setShowCartModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  // Checkout & GPS
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [isLocating, setIsLocating] = useState(false);
  const [distance, setDistance] = useState<number | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [hasSharedLocation, setHasSharedLocation] = useState(false);

  // Auth Inputs
  const [loginUser, setLoginUser] = useState('');
  const [loginPin, setLoginPin] = useState('');

  // Customer Login Inputs
  const [tempName, setTempName] = useState('');
  const [tempPIN, setTempPIN] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setIsSplashScreen(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const analytics = useMemo(() => {
    const now = new Date();
    const todayStr = now.toDateString();
    const thisMonth = now.getMonth();
    const thisYear = now.getFullYear();

    return salesHistory.reduce((acc, sale) => {
      const saleDate = new Date(sale.timestamp);
      if (saleDate.toDateString() === todayStr) {
        acc.todayRevenue += sale.total;
        acc.todayCount += 1;
      }
      if (saleDate.getMonth() === thisMonth && saleDate.getFullYear() === thisYear) {
        acc.monthRevenue += sale.total;
        acc.monthCount += 1;
      }
      return acc;
    }, { todayRevenue: 0, todayCount: 0, monthRevenue: 0, monthCount: 0 });
  }, [salesHistory]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product, quantity: 1 }];
    });
    if ("vibrate" in navigator) navigator.vibrate(40);
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === id) {
        return { ...item, quantity: Math.max(1, item.quantity + delta) };
      }
      return item;
    }));
  };

  const totalCartAmount = useMemo(() => cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0), [cart]);
  const cartCount = useMemo(() => cart.reduce((sum, item) => sum + item.quantity, 0), [cart]);

  const filteredProducts = useMemo(() => {
    let result = activeCategory === 'All' ? products : products.filter(p => p.category === activeCategory);
    if (searchQuery.trim()) {
      result = result.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
    }
    return result;
  }, [products, activeCategory, searchQuery]);

  // Use full window.location.href for accurate linking in preview environments
  const currentFullUrl = useMemo(() => window.location.href, []);

  const getLiveLocation = () => {
    setIsLocating(true);
    setLocationError(null);
    
    if (!navigator.geolocation) {
      setLocationError("Device location disable hai. Browser ki settings check karein.");
      setIsLocating(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const mapsLink = `https://www.google.com/maps?q=${latitude},${longitude}`;
        // Automatically append to address so it appears in the box immediately
        setDeliveryAddress(prev => `📍 My Live Location: ${mapsLink}\n${prev}`.trim());
        setDistance(calculateDistance(latitude, longitude, SHOP_LOCATION.lat, SHOP_LOCATION.lng));
        setHasSharedLocation(true);
        setIsLocating(false);
        alert("Location kamyabi se share ho gayi hai!");
      },
      (err) => {
        console.warn(`Geolocation Error(${err.code}): ${err.message}`);
        let msg = "Location Access Denied. Permission required.";
        if (err.code === 3) msg = "Timeout! Internet slow hai.";
        setLocationError(msg);
        setIsLocating(false);
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleCheckout = () => {
    if (!deliveryAddress.trim()) {
      alert("Please apna address ya location niche box mein likhen.");
      return;
    }

    const itemsList = cart.map(i => `▫️ *${i.product.name}*\n   Qty: ${i.quantity} | Subtotal: Rs.${i.product.price * i.quantity}`).join('\n\n');
    const deliveryFee = distance !== null && distance > 3 ? Math.ceil((distance - 3) * 35) : 0;
    const total = totalCartAmount + deliveryFee;
    
    const msg = `*🛍️ DOODLE ZONE - NEW ORDER*\n` +
                `============================\n` +
                `👤 *Customer:* ${customerProfile?.name}\n` +
                `🏠 *Shop:* ${shopInfo.name}\n` +
                `📍 *Address:* ${shopInfo.address}\n` +
                `============================\n\n` +
                `🛒 *ORDER ITEMS:*\n\n${itemsList}\n\n` +
                `----------------------------\n` +
                `💵 *Items Total:* Rs. ${totalCartAmount}\n` +
                `🚚 *Delivery:* Rs. ${deliveryFee}\n` +
                `💰 *NET PAYABLE:* Rs. ${total}\n` +
                `----------------------------\n\n` +
                `📍 *CUSTOMER ADDRESS:*\n${deliveryAddress}\n\n` +
                `============================\n` +
                `_Sent via Doodle Zone App_`;

    window.open(`https://wa.me/923445498156?text=${encodeURIComponent(msg)}`, '_blank');
    
    const newRecord: SaleRecord = { 
      id: Date.now().toString(), 
      timestamp: Date.now(), 
      total: total, 
      itemCount: cartCount,
      items: [...cart],
      customerName: customerProfile?.name || 'Guest'
    };
    const updatedHistory = [newRecord, ...salesHistory];
    setSalesHistory(updatedHistory);
    localStorage.setItem('doodle_sales_history', JSON.stringify(updatedHistory));

    setCart([]);
    setShowCheckoutModal(false);
    setShowCartModal(false);
    setActiveTab('Me');
  };

  const shareWebsite = () => {
    const msg = `Visit *Doodle Zone* Online Shop! 🛍️\nPremium Stationery, Toys & Decor.\nShop here: ${currentFullUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const copyToClipboard = async (text: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        alert('Shop link copied!');
      } else {
        // Fallback for browsers with restricted clipboard access
        const textArea = document.createElement("textarea");
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        alert('Shop link copied! (fallback)');
      }
    } catch (err) {
      console.error('Copy failed: ', err);
      alert('Copy failed. Please copy link manually.');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingProduct) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditingProduct({
          ...editingProduct,
          image: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const saveProduct = () => {
    if (editingProduct) {
      setProducts(prev => {
        const existing = prev.find(p => p.id === editingProduct.id);
        const updated = existing 
          ? prev.map(p => p.id === editingProduct.id ? editingProduct : p) 
          : [editingProduct, ...prev];
        localStorage.setItem('doodle_products', JSON.stringify(updated));
        return updated;
      });
      setShowEditModal(false);
    }
  };

  if (isSplashScreen) {
    return (
      <div className="bg-slate-950 min-h-screen flex flex-col items-center justify-center p-6 text-white overflow-hidden">
        <div className="w-28 h-28 bg-gradient-to-tr from-violet-600 to-fuchsia-600 rounded-[2.5rem] flex items-center justify-center shadow-2xl animate-bounce border-4 border-white/20">
          <svg className="w-14 h-14 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
        </div>
        <h1 className="text-4xl font-black mt-8 tracking-tighter uppercase italic">Doodle<span className="text-fuchsia-500">Zone</span></h1>
      </div>
    );
  }

  if (!customerProfile) {
    return (
      <div className="bg-slate-950 min-h-screen flex flex-col items-center justify-center p-8 text-white">
        <div className="w-full max-w-sm text-center animate-in fade-in duration-700">
          <h2 className="text-3xl font-black uppercase mb-10 tracking-tighter text-white italic">Doodle<span className="text-fuchsia-500">Zone</span></h2>
          <div className="space-y-4 text-left">
            <div>
              <p className="text-[10px] font-black uppercase text-slate-400 mb-2 px-1 tracking-widest">Name Required</p>
              <input type="text" placeholder="Apna Naam Likhen" value={tempName} onChange={e => setTempName(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm font-bold outline-none focus:border-white/30 transition-all text-white" />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase text-slate-400 mb-2 px-1 tracking-widest">Login PIN</p>
              <input type="password" placeholder="****" maxLength={4} value={tempPIN} onChange={e => setTempPIN(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm font-bold outline-none tracking-[0.5em] text-center text-white" />
            </div>
            <button onClick={() => { if(tempName.trim().length > 1 && tempPIN.length === 4) { setCustomerProfile({name:tempName, pin:tempPIN}); localStorage.setItem('doodle_customer_profile', JSON.stringify({name:tempName,pin:tempPIN})); } }} className="w-full py-5 mt-4 rounded-[2.5rem] bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-black uppercase text-[11px] tracking-widest active:scale-95 transition-all shadow-xl">Enter Shop</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fcfcfc] pb-24">
      <Header shopName={shopInfo.name} cartCount={cartCount} onSearch={setSearchQuery} onOpenCart={() => setShowCartModal(true)} isAdmin={isAdmin} />

      <main>
        {activeTab === 'Home' && (
          <div className="px-6 py-8 space-y-8 animate-in fade-in duration-500">
            <div className="flex justify-between items-end">
              <h2 className="text-4xl font-black text-slate-900 tracking-tighter uppercase leading-none">Premium<br/><span className="gradient-text">Picks.</span></h2>
              <div className="text-right">
                <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Signed In As</p>
                <p className="text-[12px] font-black text-violet-600 uppercase tracking-tighter">{customerProfile.name}</p>
              </div>
            </div>
            
            <div className="bg-slate-900 h-44 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-xl">
              <div className="relative z-10 flex flex-col justify-between h-full">
                <div>
                  <h3 className="text-2xl font-black leading-none uppercase italic tracking-tighter">B-17 Islamabad</h3>
                  <p className="text-[9px] font-bold opacity-60 mt-2 uppercase tracking-widest">E Block Near Masjid Allah o Akbar</p>
                </div>
                <button onClick={() => window.open(`https://wa.me/923445498156`, '_blank')} className="bg-[#25D366] px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest self-start shadow-lg active:scale-95 transition-all flex items-center gap-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                  Contact Shop
                </button>
              </div>
            </div>

            {/* QR Code & Sharing Section - FIXED */}
            <div className="bg-white p-10 rounded-[3rem] border-2 border-slate-50 flex flex-col items-center text-center space-y-8 android-shadow">
               <div className="space-y-1">
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">Share Our Shop</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Invite friends to Doodle Zone</p>
               </div>
               
               {/* QR CODE GENERATOR */}
               <div className="p-6 bg-white rounded-[3rem] border-4 border-slate-50 shadow-inner">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentFullUrl)}&bgcolor=ffffff&color=000000&margin=10&format=png`} 
                    alt="Shop QR Code" 
                    className="w-40 h-40 rounded-3xl"
                    onLoad={() => console.log("QR Code Loaded")}
                    onError={(e) => (e.currentTarget.src = "https://via.placeholder.com/200?text=QR+Error")}
                  />
               </div>

               <div className="w-full flex flex-col gap-4">
                  {/* DISPLAY URL & COPY BUTTON */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between overflow-hidden shadow-inner">
                     <span className="text-[10px] font-bold text-slate-400 truncate flex-1 text-left mr-4">{currentFullUrl}</span>
                     <button 
                       onClick={() => copyToClipboard(currentFullUrl)} 
                       className="text-[10px] font-black text-violet-600 uppercase underline decoration-2 active:text-fuchsia-600 transition-colors"
                     >
                        Copy Link
                     </button>
                  </div>

                  {/* SHARE ON WHATSAPP BUTTON - BRIGHT GREEN */}
                  <button 
                    onClick={shareWebsite} 
                    className="w-full py-5 rounded-[2rem] bg-[#25D366] text-white font-black uppercase text-[11px] tracking-widest flex items-center justify-center gap-3 active:scale-95 transition-all shadow-xl shadow-emerald-200"
                  >
                     <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                     SHARE ON WHATSAPP
                  </button>
               </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {isAdmin && (
                <button onClick={() => { setEditingProduct({id:Date.now().toString(), name:'New Item', price:0, category:Category.STATIONERY}); setShowEditModal(true); }} className="col-span-2 py-8 rounded-[2.5rem] border-2 border-dashed border-violet-100 bg-white flex flex-col items-center justify-center gap-2 text-violet-400 active:bg-violet-50 transition-colors">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4"/></svg>
                  <span className="text-[9px] font-black uppercase tracking-widest">Add New Product</span>
                </button>
              )}
              {filteredProducts.map(p => <ProductCard key={p.id} product={p} isAdmin={isAdmin} onAddToCart={addToCart} onEdit={(prod) => { setEditingProduct(prod); setShowEditModal(true); }} />)}
            </div>
          </div>
        )}

        {activeTab === 'Explore' && (
          <div className="px-6 py-8 animate-in slide-in-from-right duration-300">
            <h2 className="text-3xl font-black text-slate-900 mb-8 tracking-tighter uppercase">Categories</h2>
            <div className="flex gap-2 overflow-x-auto no-scrollbar mb-8 pb-2">
              {['All', ...Object.values(Category)].map(cat => (
                <button key={cat} onClick={() => setActiveCategory(cat as any)} className={`whitespace-nowrap px-6 py-3 rounded-2xl text-[9px] font-black uppercase tracking-widest transition-all ${activeCategory === cat ? 'bg-violet-600 text-white shadow-lg shadow-violet-200' : 'bg-white text-slate-400 border border-slate-100 active:bg-slate-50'}`}>{cat}</button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-4">
              {products.filter(p => activeCategory === 'All' || p.category === activeCategory).map(p => <ProductCard key={p.id} product={p} isAdmin={isAdmin} onAddToCart={addToCart} onEdit={(prod) => { setEditingProduct(prod); setShowEditModal(true); }} />)}
            </div>
          </div>
        )}

        {activeTab === 'Me' && (
           <div className="px-6 py-8 space-y-8 animate-in fade-in slide-in-from-bottom-5">
              <div className="flex flex-col items-center text-center space-y-4 py-8">
                 <div className="w-24 h-24 rounded-[2.5rem] bg-gradient-to-tr from-violet-600 to-fuchsia-600 flex items-center justify-center text-white text-3xl font-black shadow-2xl">{customerProfile.name.charAt(0)}</div>
                 <div>
                    <h3 className="text-2xl font-black text-slate-900 tracking-tighter uppercase">{customerProfile.name}</h3>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{isAdmin ? 'Shop Manager Mode' : 'Customer Account'}</p>
                 </div>
              </div>

              {isAdmin && (
                <div className="space-y-6">
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">Manager's Stats</h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white p-6 rounded-[2rem] border border-slate-50 space-y-2 android-shadow">
                       <p className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">Today's Total</p>
                       <p className="text-xl font-black text-slate-900">Rs. {analytics.todayRevenue}</p>
                       <p className="text-[9px] font-bold text-slate-300">{analytics.todayCount} Sales</p>
                    </div>
                    <div className="bg-slate-900 p-6 rounded-[2rem] shadow-xl space-y-2">
                       <p className="text-[8px] font-black text-violet-400 uppercase tracking-widest">Monthly Goal</p>
                       <p className="text-xl font-black text-white">Rs. {analytics.monthRevenue}</p>
                       <p className="text-[9px] font-bold text-slate-600">{analytics.monthCount} Sales</p>
                    </div>
                  </div>

                  <div className="space-y-4 pt-4">
                    <div className="flex justify-between items-center px-2">
                      <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Detailed History</h4>
                      <button onClick={() => { if(confirm("Clear history?")) { setSalesHistory([]); localStorage.setItem('doodle_sales_history', '[]'); } }} className="text-[8px] font-black text-rose-500 uppercase underline">Reset</button>
                    </div>
                    <div className="space-y-3">
                      {salesHistory.length === 0 ? (
                        <p className="text-center py-10 text-[10px] text-slate-300 font-bold uppercase">Empty history</p>
                      ) : (
                        salesHistory.map(sale => (
                          <div key={sale.id} className="bg-white p-5 rounded-[2rem] border border-slate-50 android-shadow space-y-4">
                            <div className="flex justify-between items-start">
                              <div>
                                <p className="text-[11px] font-black text-slate-900 uppercase">{sale.customerName}</p>
                                <p className="text-[9px] text-slate-400 font-bold">{new Date(sale.timestamp).toLocaleString()}</p>
                              </div>
                              <span className="bg-violet-50 text-violet-600 px-3 py-1 rounded-full text-[9px] font-black">Rs. {sale.total}</span>
                            </div>
                            <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                              {sale.items?.map((item, idx) => (
                                <div key={idx} className="flex-shrink-0 flex items-center gap-2 bg-slate-50 p-2 rounded-2xl border border-slate-100">
                                  <div className="w-10 h-10 bg-white rounded-xl overflow-hidden flex items-center justify-center border border-slate-200 shadow-inner">
                                    {item.product.image ? (
                                      <img src={item.product.image} className="w-full h-full object-cover" />
                                    ) : (
                                      <svg className="w-4 h-4 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                    )}
                                  </div>
                                  <div className="pr-2">
                                    <p className="text-[9px] font-black text-slate-800 line-clamp-1 w-20 uppercase">{item.product.name}</p>
                                    <p className="text-[8px] font-bold text-slate-400">x{item.quantity}</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                 {!isAdmin && (
                   <button onClick={() => { setShowLoginModal(true); setLoginUser(''); setLoginPin(''); }} className="w-full bg-white rounded-[1.5rem] p-5 flex justify-between items-center android-shadow border border-slate-50 active:scale-95 transition-all">
                      <div className="flex items-center gap-4">
                         <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                         </div>
                         <span className="text-xs font-black text-slate-700 uppercase tracking-widest">Manager Login</span>
                      </div>
                   </button>
                 )}
                 <button onClick={() => { if(confirm("Log out karein?")) { localStorage.clear(); window.location.reload(); } }} className="w-full bg-rose-50 rounded-[1.5rem] p-5 flex justify-between items-center border border-rose-100 active:scale-95 transition-all text-rose-500">
                    <span className="text-xs font-black uppercase tracking-widest mx-auto">Sign Out Account</span>
                 </button>
              </div>
           </div>
        )}
      </main>

      <nav className="glass fixed bottom-6 left-6 right-6 rounded-[2.5rem] border border-white/40 shadow-2xl px-8 py-4 flex justify-between items-center z-[60]">
         {['Home', 'Explore', 'Me'].map(t => (
            <button key={t} onClick={() => setActiveTab(t as any)} className={`flex flex-col items-center gap-1 transition-all ${activeTab === t ? 'text-violet-600 scale-110' : 'text-slate-400'}`}>
              <span className="text-[10px] font-black uppercase tracking-tighter">{t}</span>
              {activeTab === t && <div className="w-1 h-1 bg-violet-600 rounded-full"></div>}
            </button>
         ))}
      </nav>

      {showCartModal && (
         <div className="fixed inset-0 z-[100] flex items-end justify-center">
            <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm" onClick={() => setShowCartModal(false)}></div>
            <div className="bg-white w-full rounded-t-[3rem] p-8 relative z-10 android-shadow animate-in slide-in-from-bottom duration-300">
               <div className="w-12 h-1 bg-slate-100 rounded-full mx-auto mb-8"></div>
               <div className="flex justify-between items-center mb-6 px-2">
                  <h2 className="text-xl font-black text-slate-900 uppercase tracking-tighter">Your Selection</h2>
                  <button onClick={() => setShowCartModal(false)} className="text-slate-400 text-[10px] font-black uppercase tracking-widest underline decoration-2">Close</button>
               </div>
               <div className="space-y-4 max-h-[40vh] overflow-y-auto no-scrollbar mb-8">
                  {cart.length === 0 ? <p className="text-center py-12 text-slate-300 text-[10px] font-black uppercase tracking-[0.2em]">Bag is empty</p> : cart.map(item => (
                     <div key={item.product.id} className="flex gap-4 p-3 bg-slate-50 rounded-3xl items-center border border-slate-100">
                        <div className="flex-grow">
                           <h4 className="text-[11px] font-black text-slate-800 uppercase line-clamp-1">{item.product.name}</h4>
                           <p className="text-violet-600 font-black text-xs">Rs. {item.product.price}</p>
                        </div>
                        <div className="flex items-center gap-2">
                           <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-2xl border border-slate-100">
                              <button onClick={() => updateQuantity(item.product.id, -1)} className="w-6 h-6 flex items-center justify-center font-bold text-slate-400">-</button>
                              <span className="text-xs font-black text-slate-900 min-w-[20px] text-center">{item.quantity}</span>
                              <button onClick={() => updateQuantity(item.product.id, 1)} className="w-6 h-6 flex items-center justify-center font-bold text-violet-600">+</button>
                           </div>
                           <button 
                             onClick={() => removeFromCart(item.product.id)}
                             className="p-2.5 bg-rose-50 text-rose-500 rounded-2xl active:bg-rose-100 transition-all"
                           >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                           </button>
                        </div>
                     </div>
                  ))}
               </div>
               {cart.length > 0 && (
                  <button onClick={() => setShowCheckoutModal(true)} className="w-full py-5 rounded-[2.5rem] bg-violet-600 text-white font-black uppercase text-[11px] tracking-widest shadow-2xl active:scale-95 transition-all">Go to Checkout (Rs. {totalCartAmount})</button>
               )}
            </div>
         </div>
      )}

      {showCheckoutModal && (
         <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md" onClick={() => setShowCheckoutModal(false)}></div>
            <div className="bg-white w-full max-w-sm rounded-[3rem] p-8 relative z-10 android-shadow space-y-6 max-h-[90vh] overflow-y-auto no-scrollbar animate-in zoom-in duration-200">
               <div className="flex justify-between items-center border-b pb-4">
                  <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">ORDER SUMMARY</h2>
                  <button onClick={() => setShowCheckoutModal(false)} className="text-[10px] font-black text-slate-400 uppercase tracking-widest underline decoration-2">BACK</button>
               </div>
               
               <div className="space-y-4">
                  <div className="space-y-2">
                     <p className="text-[10px] font-black text-slate-500 uppercase px-1 tracking-widest">DELIVERY DETAILS</p>
                     
                     <button 
                        onClick={getLiveLocation}
                        disabled={isLocating}
                        className={`w-full py-5 rounded-[1.5rem] font-black text-[12px] uppercase flex items-center justify-center gap-2 border-2 transition-all active:scale-95 ${hasSharedLocation ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : isLocating ? 'bg-slate-50 border-slate-100 text-slate-300' : 'bg-violet-600 border-violet-500 text-white shadow-lg shadow-violet-100'}`}
                     >
                        {hasSharedLocation ? 'LOCATION ADDED ✓' : isLocating ? 'FETCHING GPS...' : 'SHARE LIVE LOCATION'}
                     </button>
                     
                     <div className="relative">
                        <textarea 
                          value={deliveryAddress} 
                          onChange={(e) => setDeliveryAddress(e.target.value)} 
                          placeholder="House #, Street #, Near by..." 
                          className="w-full bg-slate-50 border-2 border-slate-100 rounded-[1.5rem] p-5 text-[12px] font-bold outline-none h-28 focus:border-violet-500 transition-all shadow-inner focus:bg-white" 
                        />
                        <div className="absolute top-4 right-4 animate-pulse">
                           <div className="w-2 h-2 rounded-full bg-violet-400"></div>
                        </div>
                     </div>
                     
                     {locationError && <p className="text-rose-500 text-[10px] font-bold bg-rose-50 p-4 rounded-2xl text-center border-2 border-rose-100 leading-tight">{locationError}</p>}
                  </div>

                  <div className="bg-slate-50 p-6 rounded-[2rem] border-2 border-slate-100 space-y-3 shadow-inner">
                     <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest"><span>ITEMS COST</span><span>RS. {totalCartAmount}</span></div>
                     <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest"><span>SHIPPING</span><span>{distance === null ? 'FETCH GPS' : distance <= 3 ? 'FREE' : `RS. ${Math.ceil((distance - 3) * 35)}`}</span></div>
                     <div className="h-px bg-slate-200 my-2 opacity-50"></div>
                     <div className="flex justify-between items-center">
                        <span className="text-xs font-black uppercase tracking-widest text-slate-900">NET TOTAL</span>
                        <span className="text-3xl font-black text-violet-600 tracking-tighter">Rs. {totalCartAmount + (distance !== null && distance > 3 ? Math.ceil((distance - 3) * 35) : 0)}</span>
                     </div>
                  </div>
               </div>

               <div className="flex flex-col gap-3 pt-2">
                  <button 
                    onClick={handleCheckout} 
                    className={`w-full py-6 rounded-[2.5rem] font-black uppercase text-[14px] tracking-widest flex items-center justify-center gap-3 transition-all shadow-2xl active:scale-95 ${deliveryAddress.trim() ? 'bg-[#25D366] text-white shadow-[#25D366]/40 hover:bg-[#20ba59]' : 'bg-slate-200 text-slate-400 cursor-not-allowed opacity-60'}`}
                  >
                     <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                     ORDER VIA WHATSAPP
                  </button>
                  <button onClick={() => setShowCheckoutModal(false)} className="w-full py-3 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center active:text-slate-900 transition-colors">GO BACK</button>
               </div>
            </div>
         </div>
      )}

      {showLoginModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md" onClick={() => setShowLoginModal(false)}></div>
          <div className="bg-white rounded-[3rem] w-full max-w-xs relative z-10 p-10 android-shadow text-center space-y-6 animate-in zoom-in duration-200">
            <h2 className="text-xl font-black uppercase tracking-tighter italic">Doodle<span className="text-fuchsia-500">Zone</span> Admin</h2>
            <div className="space-y-4 text-left">
              <div>
                 <p className="text-[9px] font-black text-slate-400 uppercase mb-1 px-1 tracking-widest">Username</p>
                 <input 
                   type="text" 
                   value={loginUser} 
                   onChange={e => setLoginUser(e.target.value)} 
                   placeholder="Enter username" 
                   className="w-full bg-slate-50 border border-slate-100 rounded-3xl p-5 text-xs font-bold outline-none focus:border-violet-300 shadow-inner" 
                 />
              </div>
              <div>
                 <p className="text-[9px] font-black text-slate-400 uppercase mb-1 px-1 tracking-widest">Secret PIN</p>
                 <input 
                   type="password" 
                   value={loginPin} 
                   onChange={e => setLoginPin(e.target.value)} 
                   placeholder="****" 
                   maxLength={4} 
                   className="w-full bg-slate-50 border border-slate-100 rounded-3xl p-5 text-xs font-bold outline-none tracking-[1em] text-center focus:border-violet-300 shadow-inner" 
                 />
              </div>
              <button onClick={() => {
                if (loginUser.trim() === ADMIN_CREDENTIALS.username && loginPin === ADMIN_CREDENTIALS.secret) {
                  setIsAdmin(true);
                  localStorage.setItem('doodle_is_admin', 'true');
                  setShowLoginModal(false);
                  alert("Welcome, Muhammad Arif!");
                } else {
                  alert("Invalid login details!");
                }
              }} className="w-full bg-slate-900 text-white py-4 rounded-3xl font-black uppercase text-[10px] active:scale-95 transition-all shadow-xl tracking-widest">ENTER MANAGER MODE</button>
              <button onClick={() => setShowLoginModal(false)} className="w-full text-center text-slate-400 text-[9px] font-black uppercase tracking-widest underline decoration-2">CANCEL</button>
            </div>
          </div>
        </div>
      )}

      {showEditModal && editingProduct && (
        <div className="fixed inset-0 z-[130] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md" onClick={() => setShowEditModal(false)}></div>
          <div className="bg-white rounded-[3rem] w-full max-w-sm relative z-10 p-8 android-shadow space-y-6 max-h-[90vh] overflow-y-auto no-scrollbar animate-in slide-in-from-bottom duration-300">
            <h2 className="text-xl font-black uppercase tracking-tighter">Inventory Update</h2>
            
            <div className="space-y-6">
               <div className="flex flex-col items-center gap-4">
                  <div className="relative w-32 h-32 bg-slate-50 rounded-[2rem] overflow-hidden border border-slate-100 flex items-center justify-center shadow-inner group">
                     {editingProduct.image ? (
                        <img src={editingProduct.image} className="w-full h-full object-cover" alt="Preview" />
                     ) : (
                        <svg className="w-8 h-8 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                     )}
                     <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white cursor-pointer"
                     >
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                        <span className="text-[8px] font-black uppercase mt-1 tracking-widest">Change Photo</span>
                     </div>
                  </div>
                  <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
               </div>

               <div className="space-y-4">
                  <div>
                    <p className="text-[9px] font-black text-slate-400 uppercase mb-1 px-1">Product Title</p>
                    <input value={editingProduct.name} onChange={e => setEditingProduct({...editingProduct, name: e.target.value})} placeholder="Item Name" className="w-full bg-slate-50 border border-slate-100 rounded-3xl p-4 text-xs font-bold outline-none focus:bg-white transition-colors shadow-inner" />
                  </div>
                  <div className="flex gap-4">
                    <div className="w-1/2">
                      <p className="text-[9px] font-black text-slate-400 uppercase mb-1 px-1">Price (Rs)</p>
                      <input type="number" value={editingProduct.price} onChange={e => setEditingProduct({...editingProduct, price: parseInt(e.target.value) || 0})} placeholder="Price" className="w-full bg-slate-50 border border-slate-100 rounded-3xl p-4 text-xs font-bold outline-none focus:bg-white shadow-inner" />
                    </div>
                    <div className="w-1/2">
                      <p className="text-[9px] font-black text-slate-400 uppercase mb-1 px-1">Category</p>
                      <select value={editingProduct.category} onChange={e => setEditingProduct({...editingProduct, category: e.target.value as Category})} className="w-full bg-slate-50 border border-slate-100 rounded-3xl p-4 text-[10px] font-bold outline-none focus:bg-white appearance-none shadow-inner">
                        {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
               </div>
            </div>

            <div className="flex gap-4 pt-4">
               <button onClick={saveProduct} className="flex-1 bg-slate-900 text-white py-4 rounded-3xl font-black uppercase text-[10px] tracking-widest active:scale-95 transition-all shadow-xl">SAVE</button>
               <button onClick={() => { if(confirm("Are you sure?")) { setProducts(prev => { const updated = prev.filter(p => p.id !== editingProduct.id); localStorage.setItem('doodle_products', JSON.stringify(updated)); return updated; }); setShowEditModal(false); } }} className="px-6 bg-rose-50 text-rose-500 rounded-3xl font-black uppercase text-[10px] active:bg-rose-100 transition-colors">DELETE</button>
            </div>
            <button onClick={() => setShowEditModal(false)} className="w-full text-center text-slate-400 text-[9px] font-black uppercase tracking-widest underline decoration-2">DISCARD</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;