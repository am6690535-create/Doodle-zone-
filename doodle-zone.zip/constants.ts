import { Category, Product, ShopDetails } from './types';

export const INITIAL_SHOP_INFO: ShopDetails = {
  name: "Doodle Zone",
  owner: "Muhammad Arif",
  whatsapp: "03445498156",
  easypaisa: "03335240639",
  email: "doodlezone@gmail.com",
  website: "https://doodlezone.com",
  address: "B.17 Islamabad E Block near Masjid Allah o Akbar"
};

// Shop Coordinates for B-17 Islamabad
export const SHOP_LOCATION = {
  lat: 33.6687,
  lng: 72.8365
};

export const INITIAL_PRODUCTS: Product[] = [
  { id: '1', name: 'Premium Sketchbook', price: 450, category: Category.STATIONERY, image: '' },
  { id: '2', name: 'Gel Pen Set (12 colors)', price: 300, category: Category.STATIONERY, image: '' },
  { id: '3', name: 'RC Racing Car', price: 1500, category: Category.TOYS, image: '' },
  { id: '4', name: 'Soft Teddy Bear', price: 850, category: Category.TOYS, image: '' },
  { id: '5', name: 'Professional Football', price: 1200, category: Category.SPORTS, image: '' },
  { id: '6', name: 'English Willow Bat', price: 2500, category: Category.SPORTS, image: '' },
  { id: '7', name: 'HD Photocopy (B&W)', price: 10, category: Category.PHOTOCOPY, image: '' },
  { id: '8', name: 'High-Res Color Print', price: 50, category: Category.PHOTOCOPY, image: '' },
  { id: '9', name: 'Modern Wall Clock', price: 1800, category: Category.HOME_DECOR, image: '' },
  { id: '10', name: 'Ceramic Flower Vase', price: 950, category: Category.HOME_DECOR, image: '' },
];

export const ADMIN_CREDENTIALS = {
  username: 'Muhammad Arif',
  secret: '9505'
};