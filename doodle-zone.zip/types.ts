export enum Category {
  STATIONERY = 'Stationery',
  TOYS = 'Toys',
  SPORTS = 'Sports',
  PHOTOCOPY = 'Photocopy',
  HOME_DECOR = 'Home Decor'
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: Category;
  description?: string;
  image?: string;
}

export interface ShopDetails {
  name: string;
  owner: string;
  whatsapp: string;
  easypaisa: string;
  email: string;
  website: string;
  address: string;
}

export type OrderStatus = 'Pending' | 'Delivered';

export interface Order {
  id: string;
  date: string;
  productName: string;
  productImage?: string;
  quantity: number;
  subtotal: number;
  deliveryFee: number;
  distance?: number;
  total: number;
  address: string;
  status: OrderStatus;
  feedback?: string;
}